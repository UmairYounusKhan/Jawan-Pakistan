// Qno 01

let name = "Umair";
let age = 24;
let email = "umyk.2344@gmail.com";
let phoneNum = "03121212123";
let institue = "Jawan Pakistan";
let education = "Undergraduation";
let bioData = `<b>Qno 01</b><br><br>Name:${ name}<br>Age: ${ age}<br>Email: ${ email}<br> Phone Number: ${ phoneNum}<br> Institiue: ${ institue}<br>Education: ${ education} <br> <br> `
document.write(bioData);


// Qno 02

let studentName = "Umair Younus Khan"
let english = 85;
let urdu = 45;
let computer = 65;
let math = 95;
let science = 92;

let totalMarks = 500;
let obtainedMarks = english + urdu + computer + math + science;
let percentage = obtainedMarks/totalMarks*100;
let final = `<b>Qno 02</b><br> <br><strong><i>Mark Sheet</i></strong> <br>
<i>Student Name:</i><b>${studentName}</b><br>
<i>English: </i><b>${english}</b><br>
<i>Urdu: </i><b></b>${urdu}<br>
<i>Math: </i><b></b>${math}<br>
<i>Computer: </i><b>${computer}</b><br>
<i>Science: </i><b>${science}</b><br>
<i>Obtained Marks: </i> <b>${obtainedMarks}</b><br> 
<i>Percentage: </i><b>${percentage}</b>

`
document.write(final)

// Qno 03

var Name = "Umair Younus" ;
var abc ;
 var Name = " Khan";
 console.log(Name);
 var Name = "Jawad";
 
 function abc(){
    var Name = "Umair"
    console.log(Name)

 }
 abc();
 
 const Name = "Umair Younus" ;
 const Name = "Khan";
 console.log(Name);
 const Name = "Jawad";
 
 function abc(){
    var Name = "Umair";
    console.log(Name);

 }
 abc();

 
let Name = "Umair Younus" ;
 let Name = "Khan";
 console.log(Name);
let Name = "Jawad";
 
function abc(){
    var Name = "Umair";
    console.log(Name);

 }
 abc();